Neste diretório existem dois arquivos utilizados para avaliação

1) print_arvore.py 
Imprime a árvore com as features descritas em features.csv

Exemplo:
python print_arvore.py -i features.csv



2) variable_importance.py
Imprime a a importância de cada feature descrita em features.csv

Exemplo:
python variable_importance.py -i features.csv


